/**
 * @defgroup TM_STM32F4xx_Libraries
 * @brief    STM32F4xx developed by Tilen Majerle
 * @{
 *
 * Here are (or will be) listed all my STM32F4xx modules and libraries I had developed or modified for some reason.
 * 
 * From the <b>modules</b> section you can select your module for details.
 *
 * \mainpage Main page
 */
 
/** 
 * @}
 */